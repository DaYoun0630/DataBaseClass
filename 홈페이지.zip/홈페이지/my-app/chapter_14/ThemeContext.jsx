import React from "react";

const ThemeContext = React.createContext();
ThemeContext.displayName = "ThemeContextDisp";

export default ThemeContext;
