import React from "react";
import ReactDOM from 'react-dom/client';

// Theme context, default to light theme
const ThemeContext = React.createContext('light');

// Signed-in user context
const UserContext = React.createContext({
  name: 'Guest',
});

class App403 extends React.Component {
  render() {
    //const {signedInUser, theme} = this.props;
    const signedInUser={name: 'Guest'};
    const theme = 'light';
    // App component that provides initial context values
    return (
      <ThemeContext.Provider value={theme}>
        <UserContext.Provider value={signedInUser}>
          <Layout />
        </UserContext.Provider>
      </ThemeContext.Provider>
    );
  }
}

function Layout() {
    return (
      <div>
        <Sidebar />
        <Content />
      </div>
    );
}

function Sidebar() {
    return (
      <div>
        Sidebar component
      </div>
    );
}
  
  // A component may consume multiple contexts
  function Content() {
    return (
      <ThemeContext.Consumer>
        {theme => (
          <UserContext.Consumer>
            {signedInUser => (
              <ProfilePage user={signedInUser} theme={theme} />
            )}
          </UserContext.Consumer>
        )}
      </ThemeContext.Consumer>
    );
  }

function ProfilePage(props) {
    return (
      <div>
        ProfilePage user={props.user.name} theme={props.theme}
      </div>
    );
}

export default App403;
