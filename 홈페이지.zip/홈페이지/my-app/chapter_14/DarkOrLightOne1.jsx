// DarkOrLightOne1 
// Component 계층을 2단계에서 4단계로 증가
// Root DOM node(DarkOrLightOne1) > Level1 > Level2 > MainContent
import { useState, useCallback, useContext } from "react";
import React from "react";

const ThemeContext = React.createContext();
ThemeContext.displayName = "ThemeContextDisp";

function MainContent(props) {
  const { theme, toggleTheme } = useContext(ThemeContext);
  return (
    <div style={{backgroundColor: theme == "light" ? "white" : "black", color: theme == "light" ? "black" : "white",}}>
      <p>안녕하세요, 테마 변경이 가능한 웹사이트 입니다.</p>
      <button onClick={toggleTheme}>테마 변경</button>
    </div>
  );
}
function Level2(props) {
  return (<MainContent />)}
function Level1(props) {
  return (<Level2/>)}
function DarkOrLightOne1(props) {
  const [theme, setTheme] = useState("light");
  const toggleTheme = useCallback(() => {
          if (theme == "light") {setTheme("dark");
          } else if (theme == "dark") {setTheme("light");}
        }, [theme]);
  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      <Level1 />
    </ThemeContext.Provider>
  );
}

export default DarkOrLightOne1;
