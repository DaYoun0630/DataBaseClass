import { useState, useCallback } from "react";
import ThemeContext from "./ThemeContext";
import MainContent from "./MainContent";

function DarkOrLight1(props) {
    const [theme, setTheme] = useState("light");
    // ChatGPT에 문의
    // https://chatgpt.com/c/6717ba79-06bc-8012-9a02-e821850ca342
    let a = 10;
    let b = 20;

    let value = { a, b };
    console.log(value); // { a: 10, b: 20 }

    const toggleTheme = useCallback(() => {
        if (theme == "light") {
            setTheme("dark");
        } else if (theme == "dark") {
            setTheme("light");
        }
    }, [theme]);

    return (
        <ThemeContext.Provider value={{ theme, toggleTheme }}>
            <MainContent />
        </ThemeContext.Provider>
    );
}

export default DarkOrLight1;
