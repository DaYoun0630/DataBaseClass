// DarkOrLightOne2.jsx
// DarkOrLightOne1.jsx에서는 useContext훅을 사용하고 여기서는 Context.Consumer사용
import { useState, useCallback } from "react";
import React from "react";

const ThemeContext = React.createContext();
ThemeContext.displayName = "ThemeContextDisp";

function MainContent(props) {
  return (
    <ThemeContext.Consumer>
      {(value) => (
        <div style={{backgroundColor: value.theme == "light" ? "white" : "black", color: value.theme == "light" ? "black" : "white",}}>
          <p>안녕하세요, 테마 변경이 가능한 웹사이트 입니다.</p>
          <button onClick={value.toggleTheme}>테마 변경</button>
        </div>
      )}
    </ThemeContext.Consumer>);}
function Level2(props) {
  return ( <MainContent />)}
function Level1(props) {
  return (<Level2/>)}
function DarkOrLightOne2(props) {
  const [theme, setTheme] = useState("light");
  const toggleTheme = useCallback(() => {
          if (theme == "light") {setTheme("dark");
          } else if (theme == "dark") {setTheme("light");}
        }, [theme]);
  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      <Level1 />
    </ThemeContext.Provider>
  );
}

export default DarkOrLightOne2;
