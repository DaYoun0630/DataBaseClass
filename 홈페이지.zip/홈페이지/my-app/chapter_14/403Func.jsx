import React, { useState } from "react";

// Theme context, default to light theme
const ThemeContext = React.createContext();
// Signed-in user context
const UserContext = React.createContext();

function App403(props) {
    const [signedInUser, setSignedInUser] = useState({name:'Guest'});
    const [theme, setTheme] = useState("light");
    // App component that provides initial context values
    return (
      <ThemeContext.Provider value={theme}>
        <UserContext.Provider value={signedInUser}>
          <Layout />
        </UserContext.Provider>
      </ThemeContext.Provider>
    );
}

function Layout() {
    return (
      <div>
        <Sidebar />
        <Content />
      </div>
    );
}

function Sidebar() {
    return ; 
}
  
// A component may consume multiple contexts
function Content() {
  return (
    <ThemeContext.Consumer>
      {theme => (
        <UserContext.Consumer>
          {signedInUser => (
            <ProfilePage user={signedInUser} theme={theme} />
          )}
        </UserContext.Consumer>
      )}
    </ThemeContext.Consumer>
  );
}

function ProfilePage(props) {
    return (
      <div>
        ProfilePage user={props.user.name} theme={props.theme}
      </div>
    );
}

export default App403;
