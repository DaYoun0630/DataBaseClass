// DarkOrLightOne은 분석을 편하게 하기 위해 3개의 파일을 1개로 합침
import { useState, useCallback, useContext } from "react";
import React from "react";
// ThemeContext.jsx
const ThemeContext = React.createContext();
ThemeContext.displayName = "ThemeContextDisp";

// MainContent.jsx
function MainContent(props) {
  const { theme, toggleTheme } = useContext(ThemeContext);
  return (
    <div style={{backgroundColor: theme == "light" ? "white" : "black", color: theme == "light" ? "black" : "white",}}>
      <p>안녕하세요, 테마 변경이 가능한 웹사이트 입니다.</p>
      <button onClick={toggleTheme}>테마 변경</button>
    </div>
  );
}

// DarkOrLight.jsx
function DarkOrLightOne(props) {
  const [theme, setTheme] = useState("light");
  const toggleTheme = useCallback(() => {
          if (theme == "light") {setTheme("dark");
          } else if (theme == "dark") {setTheme("light");}
        }, [theme]);
  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      <MainContent />
    </ThemeContext.Provider>
  );
}

export default DarkOrLightOne;
