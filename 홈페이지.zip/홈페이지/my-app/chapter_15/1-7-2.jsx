const styles = {
    wrapper: {
        color: "red",
        textDecoration : "underline"
    },
    block: {
        color: "green",
        textDecoration : "underline"
    },
};

function Blocks(props) {
    return (
        <div style={styles.wrapper}>
          parent div 태그
          <div style={styles.block}>
            &nbsp;&nbsp;child1 div 태그
          </div>
          <div style={{color: "blue", textDecoration : "underline"}}>
            &nbsp;&nbsp;child2 div 태그
          </div>
        </div>
      );
}

export default Blocks;
