import styled from "styled-components";

const Wrapper = styled.div`
  color: ${(props) => props.color };
  text-decoration : underline;
`;
const Block = styled.div`
    color: green;
    text-decoration : underline;
`;

function Blocks(props) {
    return (
        <Wrapper color="red">
          parent div 태그
          <Block>
            &nbsp;&nbsp;child div 태그
          </Block>
        </Wrapper>
      );
}

export default Blocks;
