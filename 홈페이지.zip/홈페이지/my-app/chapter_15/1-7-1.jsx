/* CSS 스타일 시트 만드는 3가지 방법
1. style 속성 사용
2. <style> 태그 사용
3. css파일 사용
jsx 파일에서는 <style> 태그 사용 불가능
이유는 웹기초교재 161쪽 <style>태그는 반드시 <head>태그 내에서만 작성가능
*/
/* 스타일 합치기(cascadding) 우선 순위 : 웹기초교재 167쪽
우선순위 높음 > style속성 > <style>태그 > css파일 > 우선순위 낮음
*/
// css파일 사용사례
import './1-7-1.css';
/*
// <style> 태그 사용 불가능 사례 : Error발생
<style>
div { 
  color : blue; 
}
</style>
*/

function Blocks(props) {
  return (
    <div>
      parent div 태그
      {/* style 속성 사용 사례 */}
      <div style={{ color: "green", textDecoration : "underline"}}>
        &nbsp;&nbsp;child div 태그
      </div>
    </div>
  );
}

export default Blocks;
