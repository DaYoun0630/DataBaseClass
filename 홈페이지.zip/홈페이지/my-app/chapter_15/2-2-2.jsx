import styled from "styled-components";

const Wrapper = styled.div`
  color: ${(props) => props.color };
  text-decoration : underline;
`;

function Block(props) {
  return ( 
    <div style={{color: props.color, textDecoration : props.textDecoration}}>
      &nbsp;&nbsp;child div 태그
    </div>
  );
}

function Blocks(props) {
  return (
    <Wrapper color="red">
      parent div 태그
      <Block color="green" textDecoration="underline"/>
    </Wrapper>
  );
}

export default Blocks;
