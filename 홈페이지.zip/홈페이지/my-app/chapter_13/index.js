import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';

import Library from './chapter_03/Library3';
import Clock from './chapter_04/Clock';
//import CommentList from './chapter_05/CommentList';
import CommentList from './chapter_05_js/CommentList';
import NotificationList from './chapter_06/NotificationList';
import NotificationList1 from './chapter_06/NotificationList1';
import NotificationList2 from './chapter_06/NotificationList2';
import NotificationList3 from './chapter_06/NotificationList3';
//import Counter from './chapter_07/215_noHook';
//import Counter from './chapter_07/216_useState';
import Counter from './chapter_07/219_useEffect';
import Accommodate from './chapter_07/Accommodate';
import Accommodate1 from './chapter_07/Accommodate1';
import ConfirmButton from './chapter_08/ConfirmButton';
import ConfirmButton1 from './chapter_08/ConfirmButton1';
import LandingPage from './chapter_09/LandingPage';
import AttendanceBook from './chapter_10/AttendanceBook';
import SignUp from './chapter_11/SignUp';
import Calculator from './chapter_12/Calculator';
import ProfileCard from './chapter_13/ProfileCard';
import DarkOrLight from './chapter_14/DarkOrLight';
import DarkOrLight1 from './chapter_14/DarkOrLight1';
import DarkOrLightOne from './chapter_14/DarkOrLightOne';
import DarkOrLightOne1 from './chapter_14/DarkOrLightOne1';
import DarkOrLightOne2 from './chapter_14/DarkOrLightOne2';
//import App403 from './chapter_14/403Class';
import App403 from './chapter_14/403Func';
//import Blocks from './chapter_15/Blocks';
//import Blocks from './chapter_15/1-7-1';
//import Blocks from './chapter_15/1-7-2';
//import Blocks from './chapter_15/2-2-1';
//import Blocks from './chapter_15/2-2-2';
//import Blocks from './chapter_15/2-2-3';
//import Sample from './chapter_15/446';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <Blocks />
  </React.StrictMode>
);

/*
root.render(
    <NotificationList1 />
);
*/

/*
setInterval( () => {
  root.render(React.createElement(Clock));
},1000);
*/
// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();

