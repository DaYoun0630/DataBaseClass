document.querySelectorAll('.reward button').forEach(button => {
    button.addEventListener('click', () => {
        alert('후원이 완료되었습니다!');
    });
});
